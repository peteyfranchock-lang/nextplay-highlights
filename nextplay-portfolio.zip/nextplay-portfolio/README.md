# NextPlay Highlights — Peter Franchock

Static personal portfolio and browser-only athlete showcase prototype. Open `index.html` to preview, or deploy the folder to Netlify.

## Portfolio rubric
- About: personal 100–150-word biography
- Three work/experience entries: NextPlay, Ithaca basketball, website design process
- Skills and interests
- Contact: Pfranchock@ithaca.edu
- Custom navy/lime/cream palette, Barlow Condensed + DM Sans, basketball-court signature art
- Responsive layout
- Interactive athlete profile creation and local highlight media preview

## Important limitation
This is a static website with **no backend**. Athlete text cards are stored in the browser's localStorage on that device only. Selected image/video files are previewed using temporary object URLs and **are not uploaded or persisted**. No one else can see submitted profiles. To accept public uploads from other players, you would need a hosted storage service, moderation, privacy/consent rules, and a backend, which are outside the assignment's no-backend requirements.

## Before submission
- Confirm all biographical statements and three portfolio items are accurate.
- Add your own licensed photo/video assets if desired.
- Conduct peer testing and document three actual changes.
- Commit the code to GitHub, deploy on Netlify, and submit both URLs and your reflection.
